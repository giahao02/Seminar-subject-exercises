#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <map>
#include <algorithm>
#include <unordered_set>
using namespace std;

vector<int> welshPowell(vector<vector<int>>& graph) {
    int V = graph.size() - 1;
    vector<pair<int, int>> degrees;
    
    // Tinh do bac cua tung dinh va luu vao vector degrees
    for (int i = 1; i <= V; ++i) {
        int degree = 0;
        for (int j = 1; j <= V; ++j) {
            degree += graph[i][j];
        }
        degrees.push_back({degree, i});
    }
	
	// Sap xep cac dinh giam dan theo bac
    sort(degrees.rbegin(), degrees.rend());

    vector<int> colors(V + 1, 0);
    int numColors = 0;
    
    // Duyet qua tung dinh theo thu tu da sap xep
    while (!degrees.empty()) {
        int node = degrees.front().second;
        degrees.erase(degrees.begin());

        bool colorFound = false;
        for (int c = 1; c <= numColors; ++c) {
            bool canColor = true;
            for (int i = 1; i <= V; ++i) {
                if (graph[node][i] == 1 && colors[i] == c) {
                    canColor = false;
                    break;
                }
            }
            if (canColor) {
                colors[node] = c;
                colorFound = true;
                break;
            }
        }
        
        // Neu khong tim duoc mau, tang so mau va gan cho dinh
        if (!colorFound) {
            colors[node] = ++numColors;
        }
    }

    return colors;
}

vector<int> dsatur(vector<vector<int>>& graph) {
    int V = graph.size() - 1;
    vector<int> colors(V + 1, 0);
    int numColors = 0;
	
	// Lap cho den khi tat ca cac dinh deu duoc to mau
    while (true) {
        int maxSaturation = -1;
        int vertexToColor = -1;

        // Tim dinh co do bao hoa (saturation) cao nhat
        for (int i = 1; i <= V; ++i) {
            if (colors[i] == 0) {
                unordered_set<int> saturatedColors;
                
                // Kiem tra mau cua cac dinh ke
                for (int j = 1; j <= V; ++j) {
                    if (graph[i][j] == 1 && colors[j] != 0) {
                        saturatedColors.insert(colors[j]);
                    }
                }
                
                // Tinh do bao hoa
                int saturation = saturatedColors.size();
                
                // Neu do bao hoa cao hon, cao nhat thong tin
                if (saturation > maxSaturation) {
                    maxSaturation = saturation;
                    vertexToColor = i;
                }
            }
        }

        // Neu khong con dinh nao chua duoc to mau, thoat khoi vong lap
        if (vertexToColor == -1) {
            break;
        }

        // Tim mau cho dinh duoc chon
        unordered_set<int> neighborColors;
        for (int i = 1; i <= V; ++i) {
            if (graph[vertexToColor][i] == 1 && colors[i] != 0) {
                neighborColors.insert(colors[i]);
            }
        }

        // Chon mau chua duoc su dung boi cac dinh ke
		int chosenColor = 1;
        while (neighborColors.count(chosenColor) > 0) {
            ++chosenColor;
        }

        // Gan mau cho dinh duoc chon va cap nhat so luong mau da duoc su dung
		colors[vertexToColor] = chosenColor;
        numColors = max(numColors, chosenColor);
    }

    return colors;
}

int main() {
    ifstream inputFile("23.txt");
    if (!inputFile) {
        cout << "Could not open input file." << endl;
        return 1;
    }

    int V;
    inputFile >> V;

    vector<vector<int>> graph(V + 1, vector<int>(V + 1, 0));

    for (int i = 1; i <= V; ++i) {
        for (int j = 1; j <= V; ++j) {
            inputFile >> graph[i][j];
        }
    }

    inputFile.close();
	
	// Su dung ham welsh & powell algorithm de to mau
    vector<int> colors = welshPowell(graph);
    //
    
    // Su dung ham dsatur algorithm de to mau
	// vector<int> colors = dsatur(graph);
	//
	
    map<int, vector<int>> colorMap;
    int numColors = 0;
    for (int i = 1; i <= V; ++i) {
        colorMap[colors[i]].push_back(i);
        numColors = max(numColors, colors[i]);
    }

    cout << "Cach to:" << endl;
    for (int i = 1; i <= numColors; ++i) {
        cout << "Mau " << i << ": ";
        for (int vertex : colorMap[i]) {
            cout << vertex << " ";
        }
        cout << endl;
    }

    cout << "So mau can de to: " << numColors << endl;

    return 0;
}

