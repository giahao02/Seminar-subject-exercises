#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include <algorithm>

using namespace std;

struct Node {
    int id;
    int gCost;  // Chi phi tich luy tu nguon den nut hien tai
    int hCost;  // Luy gia tu nut hien tai den dich
    vector<int> path;  // Duong di tu nguon den nut hien tai

    // Toan tu so sanh de su dung trong hang doi uu tien
	bool operator>(const Node& other) const {
        return gCost + hCost > other.gCost + other.hCost;
    }
};

class Graph {
    

public:
	unordered_map<int, vector<pair<int, int>>> adjList;
	
	// Them mot canh vao do thi
    void addEdge(int src, int dest, int cost) {
        adjList[src].push_back(make_pair(dest, cost));
        adjList[dest].push_back(make_pair(src, cost));
    }

    // Thuat toan A* de tim duong di ngan nhat tu nguon den dich
	vector<int> astar(int src, int dest, vector<int>& heuristic) {
		// Hang doi uu tien de duyet cac nut theo thu tu chi phi tang dan
        priority_queue<Node, vector<Node>, greater<Node>> pq;
        unordered_map<int, int> gCostMap;
        
        // Them duong di ban dau tu nguon den nut xuat phat
        pq.push({src, 0, heuristic[src], {src}});
        
        // Chi phi tu nguon den chinh no la 0
        gCostMap[src] = 0;

        while (!pq.empty()) {
            Node current = pq.top();
            pq.pop();

            int currentNode = current.id;
            int currentCost = current.gCost;

            if (currentNode == dest) {
            	
            	// Tra ve duong di ngan nhat neu den duoc nut dich
                return current.path;
            }

            // Tim kiem cac nut ke
            for (auto neighbor : adjList[currentNode]) {
                int neighborNode = neighbor.first;
                int cost = neighbor.second;
                int newCost = currentCost + cost;
                vector<int> newPath = current.path;
                
                // Them nut ke vao duong di
                newPath.push_back(neighborNode);
                
                if (gCostMap.find(neighborNode) == gCostMap.end() || newCost < gCostMap[neighborNode]) {
                    gCostMap[neighborNode] = newCost;
                    pq.push({neighborNode, newCost, heuristic[neighborNode], newPath});
                }
            }
        }

        // Tra ve mot vector rong neu khong co duong di tu nguon den dich
		return vector<int>();
    }
};

int main() {
    ifstream inputFile("graph4.txt");
    int n, m, s, t;
    inputFile >> n >> m >> s >> t;

    Graph g;
    for (int i = 0; i < m; ++i) {
        int u, v, w;
        inputFile >> u >> v >> w;
        g.addEdge(u, v, w);
    }

    vector<int> heuristic(n);
    for (int i = 0; i < n; ++i) {
        inputFile >> heuristic[i];
    }

    inputFile.close();

    vector<int> path = g.astar(s, t, heuristic);

    if (path.empty()) {
        cout << "Khong tim thay duong di phu hop!" << endl;
    } else {
        cout << "Duong di: ";
        for (int node : path) {
            cout << node << "-> ";
        }
        cout << endl;

        // Hien thi chi phi
        int totalCost = 0;
        for (int i = 0; i < path.size() - 1; ++i) {
            int u = path[i];
            int v = path[i + 1];
            for (auto neighbor : g.adjList[u]) {
                if (neighbor.first == v) {
                    totalCost += neighbor.second;
                    break;
                }
            }
        }
        cout << "Chi phi: " << totalCost << endl;
    }

    return 0;
}

