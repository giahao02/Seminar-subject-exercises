#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <limits>

using namespace std;

// Gia tri vo cung lon duoc su dung de bieu dien v� c�ng (infinity) trong thuat toan
const int INF = numeric_limits<int>::max();

// Ham doc du lieu dau vao cho GTS1 tu file
vector<vector<int>> readInputGTS1(string filename, int& n, int& u) {
    ifstream inputFile(filename);
    inputFile >> n >> u;
	
	//Doc ma tran chi phi tu file va luu vao costMatrix
    vector<vector<int>> costMatrix(n + 1, vector<int>(n + 1, 0));
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            inputFile >> costMatrix[i][j];
        }
    }

    inputFile.close();
    return costMatrix;
}

// Ham doc du lieu dau vao cho GTS2 tu file
vector<vector<int>> readInputGTS2(string filename, int& n, int& p, vector<int>& startCities) {
    ifstream inputFile(filename);
    inputFile >> n >> p;

	// Doc danh sach cac thanh pho bat dau va luu vao startCities
    startCities.resize(p);
    for (int i = 0; i < p; ++i) {
        inputFile >> startCities[i];
    }

	// Doc ma tran chi phi tu file va luu vao costMatrix
    vector<vector<int>> costMatrix(n + 1, vector<int>(n + 1, 0));
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            inputFile >> costMatrix[i][j];
        }
    }

    inputFile.close();
    return costMatrix;
}

//Ham thuc hien thuat toan GTS1 tren mot ma tran chi phi va tra ve hanh trinh v� chi phi tuong ung
pair<vector<int>, int> GTS1(vector<vector<int>>& costMatrix, int n, int u) {
    vector<int> path;
    vector<bool> visited(n + 1, false);
    int totalCost = 0;

    path.push_back(u);
    visited[u] = true;

    for (int i = 1; i < n; ++i) {
        int minCost = INF;
        int nextCity = -1;

        // Tim thanh pho ke tiep co chi phi nho nhat tu thanh pho hien tai
		for (int j = 1; j <= n; ++j) {
            if (!visited[j] && costMatrix[u][j] < minCost) {
                minCost = costMatrix[u][j];
                nextCity = j;
            }
        }

        if (nextCity == -1) {
            // Khong con thanh pho chua di
            break;
        }

        // Them thanh pho ke tiep vao hanh trinh va cap nhat chi phi
		path.push_back(nextCity);
        visited[nextCity] = true;
        totalCost += minCost;
        u = nextCity;
    }

    // Them chi phi de quay lai thanh pho xuat phat vao tong chi phi
    totalCost += costMatrix[path.back()][path.front()];
    path.push_back(path.front());

    return make_pair(path, totalCost);
}

// Ham thuc hien thuat toan GTS2 tren mot ma tran chi phi va tra ve hanh trinh va chi phi tot nhat
pair<vector<int>, int> GTS2(vector<vector<int>>& costMatrix, int n, int p, const vector<int>& startCities) {
    int bestCost = INF;
    vector<int> bestPath;

	// Duyet qua cac thanh pho bat dau va chay thuat toan GTS1, luu ket qua tot nhat
    for (int i = 0; i < p; ++i) {
        int startCity = startCities[i];
        pair<vector<int>, int> result = GTS1(costMatrix, n, startCity);
        int currentCost = result.second;
        if (currentCost < bestCost) {
            bestCost = currentCost;
            bestPath = result.first;
        }
    }

    return make_pair(bestPath, bestCost);
}

int main() {
    string filename = "GTS2c.txt";
    
    // Su dung GST1
	/*  int n, u;
    vector<vector<int>> costMatrix = readInputGTS1(filename, n, u);
    pair<vector<int>, int> result = GTS1(costMatrix, n, u);
	*/
	
    // Su dung GTS2
    int n, p;
    vector<int> startCities;
    vector<vector<int>> costMatrix = readInputGTS2(filename, n, p, startCities);
    pair<vector<int>, int> result = GTS2(costMatrix, n, p, startCities);
	//
	
    vector<int> path = result.first;
    int totalCost = result.second;

    cout << "Duong di tot nhat: ";
    for (int city : path) {
        cout << city << "-> ";
    }
    cout << endl;

    cout << "Chi phi: " << totalCost << endl;

    return 0;
}

